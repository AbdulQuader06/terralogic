import React, { useState } from "react";
import { ChatPanel } from "./components/ChatPanel";
import { MapPanel } from "./components/MapPanel";
import { MapState } from "./types";

export default function App() {
  const [mapState, setMapState] = useState<MapState>({
    center: [20.5937, 78.9629], // Center of India
    zoom: 5,
    layers: [],
    markers: [],
    drawnFeatures: [],
    baseMap: "osm",
  });

  return (
    <div className="flex h-screen w-full overflow-hidden bg-slate-100 font-sans">
      <ChatPanel mapState={mapState} setMapState={setMapState} />
      <div className="flex-1 relative h-full">
        <MapPanel mapState={mapState} setMapState={setMapState} />
      </div>
    </div>
  );
}
