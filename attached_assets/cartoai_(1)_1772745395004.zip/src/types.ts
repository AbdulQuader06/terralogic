export interface MapState {
  center: [number, number];
  zoom: number;
  layers: GeoJSONLayer[];
  markers: MapMarker[];
  drawnFeatures: any[]; // GeoJSON features drawn by the user
  baseMap: "osm" | "esri_satellite" | "esri_street";
}

export interface GeoJSONLayer {
  id: string;
  name: string;
  data: any; // GeoJSON data
  color?: string;
  visible?: boolean;
}

export interface MapMarker {
  id: string;
  position: [number, number];
  title: string;
  description?: string;
  visible?: boolean;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model" | "system";
  content: string;
  isThinking?: boolean;
}
