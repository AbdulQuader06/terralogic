import React, { useEffect, useRef } from "react";
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  GeoJSON,
  useMap,
  FeatureGroup,
} from "react-leaflet";
import { EditControl } from "react-leaflet-draw";
import "leaflet/dist/leaflet.css";
import "leaflet-draw/dist/leaflet.draw.css";
import L from "leaflet";
import { MapState } from "../types";
import { Layers, Eye, EyeOff } from "lucide-react";

// Fix for default marker icon in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl:
    "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

const BASE_MAPS = {
  osm: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  },
  esri_satellite: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    attribution:
      "Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community",
  },
  esri_street: {
    url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
    attribution:
      "Tiles &copy; Esri &mdash; Source: Esri, DeLorme, NAVTEQ, USGS, Intermap, iPC, NRCAN, Esri Japan, METI, Esri China (Hong Kong), Esri (Thailand), TomTom, 2012",
  },
};

function MapUpdater({
  center,
  zoom,
}: {
  center: [number, number];
  zoom: number;
}) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

interface MapPanelProps {
  mapState: MapState;
  setMapState: React.Dispatch<React.SetStateAction<MapState>>;
}

export function MapPanel({ mapState, setMapState }: MapPanelProps) {
  const [showLayersMenu, setShowLayersMenu] = React.useState(false);
  const featureGroupRef = useRef<L.FeatureGroup>(null);

  const onCreated = (e: any) => {
    const { layerType, layer } = e;
    const geojson = layer.toGeoJSON();
    
    // Add a unique ID to the feature
    geojson.id = crypto.randomUUID();
    geojson.properties = geojson.properties || {};
    geojson.properties.type = layerType;
    geojson.properties.name = `Drawn ${layerType} ${new Date().toLocaleTimeString()}`;

    setMapState((s) => ({
      ...s,
      drawnFeatures: [...(s.drawnFeatures || []), geojson],
    }));
  };

  const onEdited = (e: any) => {
    const { layers: editedLayers } = e;
    const editedGeoJSON: any[] = [];
    editedLayers.eachLayer((layer: any) => {
      editedGeoJSON.push(layer.toGeoJSON());
    });
    
    setMapState((s) => {
      const newFeatures = [...(s.drawnFeatures || [])];
      editedGeoJSON.forEach(edited => {
        const index = newFeatures.findIndex(f => f.id === edited.id);
        if (index !== -1) {
          newFeatures[index] = edited;
        }
      });
      return { ...s, drawnFeatures: newFeatures };
    });
  };

  const onDeleted = (e: any) => {
    const { layers: deletedLayers } = e;
    const deletedIds: string[] = [];
    deletedLayers.eachLayer((layer: any) => {
      const geojson = layer.toGeoJSON();
      if (geojson.id) deletedIds.push(geojson.id);
    });

    setMapState((s) => ({
      ...s,
      drawnFeatures: (s.drawnFeatures || []).filter(f => !deletedIds.includes(f.id)),
    }));
  };

  const toggleLayerVisibility = (id: string) => {
    setMapState(s => ({
      ...s,
      layers: s.layers.map(l => l.id === id ? { ...l, visible: l.visible === false ? true : false } : l)
    }));
  };

  return (
    <div className="h-full w-full relative z-0">
      <MapContainer
        center={mapState.center}
        zoom={mapState.zoom}
        style={{ height: "100%", width: "100%" }}
        zoomControl={false}
      >
        <MapUpdater center={mapState.center} zoom={mapState.zoom} />
        <TileLayer
          url={BASE_MAPS[mapState.baseMap].url}
          attribution={BASE_MAPS[mapState.baseMap].attribution}
        />

        <FeatureGroup ref={featureGroupRef}>
          <EditControl
            position="topleft"
            onCreated={onCreated}
            onEdited={onEdited}
            onDeleted={onDeleted}
            draw={{
              rectangle: true,
              polygon: true,
              circle: true,
              circlemarker: false,
              marker: true,
              polyline: true,
            }}
          />
        </FeatureGroup>

        {mapState.markers.map((marker) => (
          (marker.visible !== false) && (
            <Marker key={marker.id} position={marker.position}>
              <Popup>
                <div className="font-semibold">{marker.title}</div>
                {marker.description && (
                  <div className="text-sm text-gray-600">
                    {marker.description}
                  </div>
                )}
              </Popup>
            </Marker>
          )
        ))}

        {mapState.layers.map((layer) => (
          (layer.visible !== false) && (
            <GeoJSON
              key={layer.id}
              data={layer.data}
              style={{ color: layer.color || "#3388ff", weight: 2, opacity: 0.8 }}
              onEachFeature={(feature, layer) => {
                if (feature.properties && feature.properties.name) {
                  layer.bindPopup(feature.properties.name);
                }
              }}
            />
          )
        ))}
      </MapContainer>

      {/* Map Controls Overlay */}
      <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2 items-end">
        <div className="bg-white rounded-lg shadow-md p-2 flex flex-col gap-2">
          <button
            onClick={() => setMapState((s) => ({ ...s, baseMap: "osm" }))}
            className={`px-3 py-1 text-xs rounded ${mapState.baseMap === "osm" ? "bg-blue-100 text-blue-700 font-medium" : "hover:bg-gray-100"}`}
          >
            Street
          </button>
          <button
            onClick={() =>
              setMapState((s) => ({ ...s, baseMap: "esri_satellite" }))
            }
            className={`px-3 py-1 text-xs rounded ${mapState.baseMap === "esri_satellite" ? "bg-blue-100 text-blue-700 font-medium" : "hover:bg-gray-100"}`}
          >
            Satellite
          </button>
          <button
            onClick={() => {
              const featureCollection = {
                type: "FeatureCollection",
                features: [
                  ...mapState.layers.map((l) => l.data),
                  ...(mapState.drawnFeatures || [])
                ],
              };
              const blob = new Blob(
                [JSON.stringify(featureCollection, null, 2)],
                { type: "application/json" },
              );
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url;
              a.download = "cartoai_export.geojson";
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="px-3 py-1 text-xs rounded hover:bg-gray-100 text-slate-700 font-medium mt-2 border-t border-slate-200 pt-2"
            title="Download GIS Ready Output"
          >
            Export GeoJSON
          </button>
        </div>

        {/* Layer Toggle Menu */}
        <div className="bg-white rounded-lg shadow-md w-48 overflow-hidden">
          <button 
            onClick={() => setShowLayersMenu(!showLayersMenu)}
            className="w-full px-3 py-2 text-sm font-medium text-slate-700 flex items-center justify-between hover:bg-slate-50"
          >
            <div className="flex items-center gap-2">
              <Layers size={16} />
              Layers
            </div>
            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">
              {mapState.layers.length}
            </span>
          </button>
          
          {showLayersMenu && mapState.layers.length > 0 && (
            <div className="border-t border-slate-100 max-h-64 overflow-y-auto">
              {mapState.layers.map(layer => (
                <div key={layer.id} className="flex items-center justify-between px-3 py-2 hover:bg-slate-50 border-b border-slate-50 last:border-0">
                  <span className="text-xs text-slate-600 truncate pr-2" title={layer.name}>
                    {layer.name}
                  </span>
                  <button 
                    onClick={() => toggleLayerVisibility(layer.id)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    {layer.visible === false ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              ))}
            </div>
          )}
          {showLayersMenu && mapState.layers.length === 0 && (
            <div className="px-3 py-4 text-xs text-slate-400 text-center border-t border-slate-100">
              No layers added yet
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
