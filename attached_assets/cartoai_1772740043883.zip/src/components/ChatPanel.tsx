import React, { useState, useRef, useEffect } from "react";
import {
  Send,
  Loader2,
  Map as MapIcon,
  Layers,
  Search,
  BrainCircuit,
  Database,
  X,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { ChatMessage, MapState } from "../types";
import {
  createMainChatSession,
  executeSearchPlaces,
  executeSearchWeb,
  executeAnalyzeSite,
} from "../services/gemini";
import { cn } from "../lib/utils";

const DATA_CATEGORIES = [
  {
    name: "Terrain & Physical Geography",
    items: ["Elevation (DEM)", "Slope", "Aspect", "Terrain ruggedness", "Landforms", "Contours", "Watersheds", "Drainage basins", "Soil type", "Soil fertility"]
  },
  {
    name: "Hydrology & Water Systems",
    items: ["Rivers", "Streams", "Lakes", "Reservoirs", "Wetlands", "Flood risk zones", "Floodplains", "Groundwater aquifers", "Water table depth", "Drainage networks"]
  },
  {
    name: "Climate & Environmental",
    items: ["Rainfall distribution", "Temperature distribution", "Wind patterns", "Solar radiation", "Air pollution levels", "Noise pollution", "Heat island zones", "Climate zones", "Drought risk", "Storm paths"]
  },
  {
    name: "Land & Ecology",
    items: ["Land use", "Land cover", "Forest cover", "Deforestation areas", "Biodiversity hotspots", "Wildlife habitats", "Protected areas", "National parks", "Mangroves", "Grasslands"]
  },
  {
    name: "Agriculture & Rural",
    items: ["Cropland distribution", "Crop types", "Irrigation networks", "Agricultural productivity", "Soil moisture", "Pasture lands", "Agricultural suitability", "Farm boundaries", "Plantation areas", "Livestock density"]
  },
  {
    name: "Urban & Built Environment",
    items: ["Infrastructure", "Building footprints", "Building heights", "Land parcels", "Zoning areas", "Residential areas", "Commercial areas", "Industrial zones", "Slums", "Urban density"]
  },
  {
    name: "Transportation & Mobility",
    items: ["Road networks", "Railways", "Metro systems", "Bus routes", "Bus stops", "Airports", "Ports", "Bicycle lanes", "Pedestrian pathways", "Traffic congestion"]
  },
  {
    name: "Public Services & Facilities",
    items: ["Schools", "Colleges", "Hospitals", "Clinics", "Fire stations", "Police stations", "Government buildings", "Community centers", "Libraries", "Parks"]
  },
  {
    name: "Utilities & Infrastructure",
    items: ["Water supply pipelines", "Sewer networks", "Stormwater drainage", "Electricity grid lines", "Power substations", "Gas pipelines", "Telecommunication towers", "Internet fiber networks", "Waste collection zones", "Landfills"]
  },
  {
    name: "Risk, Hazards & Social Data",
    items: ["Landslide risk zones", "Earthquake hazard zones", "Coastal erosion zones", "Tsunami risk areas", "Fire risk zones", "Crime distribution", "Population density", "Demographic distribution", "Economic activity zones", "Poverty zones"]
  },
  {
    name: "Urban Form & Building Data",
    items: ["Floor area ratio (FAR)", "Building age", "Building construction type", "Roof type", "Roof materials", "Building energy consumption", "Historical buildings", "Vacant buildings", "Under-construction buildings", "Urban skyline profile"]
  },
  {
    name: "Urban Planning & Development",
    items: ["Master plan zones", "Development control zones", "Future land use plans", "Redevelopment zones", "Urban growth boundaries", "Special economic zones", "Smart city project areas", "Transit-oriented development zones", "Mixed-use development zones", "Land value zones"]
  },
  {
    name: "Transportation & Mobility Analytics",
    items: ["Travel time surfaces", "Accessibility to public transport", "Commuting patterns", "Origin-destination travel flows", "Parking availability zones", "Electric vehicle charging stations", "Traffic accident hotspots", "Ride-sharing pickup zones", "Logistics hubs", "Freight routes"]
  },
  {
    name: "Utilities & Urban Services",
    items: ["Water demand zones", "Electricity demand zones", "Internet coverage quality", "Mobile network signal strength", "Street lighting coverage", "Smart sensors / IoT networks", "Waste recycling centers", "Waste generation zones", "Stormwater retention basins", "Urban drainage capacity"]
  },
  {
    name: "Environmental Monitoring",
    items: ["Tree canopy coverage", "Urban green corridors", "Urban biodiversity zones", "Air quality monitoring stations", "Carbon emission distribution", "Noise monitoring stations", "Soil contamination zones", "Brownfield sites", "Environmental remediation sites", "Ecological restoration zones"]
  },
  {
    name: "Climate Adaptation & Sustainability",
    items: ["Sea level rise risk areas", "Coastal flood projections", "Urban heat vulnerability", "Cooling corridors", "Renewable energy potential zones", "Solar rooftop potential", "Wind energy potential", "Carbon sequestration areas", "Climate resilience zones", "Green infrastructure networks"]
  },
  {
    name: "Public Health & Social Infrastructure",
    items: ["Disease outbreak hotspots", "Health accessibility zones", "Emergency response times", "Ambulance coverage areas", "Vaccination coverage zones", "Food deserts", "Nutrition access zones", "Childcare facilities", "Elder care facilities", "Disability accessibility infrastructure"]
  },
  {
    name: "Economic & Commercial Activity",
    items: ["Business density", "Retail clusters", "Industrial output zones", "Commercial footfall zones", "Tourism hotspots", "Night-time economy zones", "Market areas", "Property price distribution", "Rental value zones", "Employment density"]
  },
  {
    name: "Cultural & Social Spaces",
    items: ["Religious institutions", "Cultural heritage sites", "Museums and galleries", "Festivals and event zones", "Public art installations", "Historical districts", "Film shooting locations", "Cultural tourism routes", "Community gathering spaces", "Traditional craft clusters"]
  },
  {
    name: "Advanced Spatial Analytics Layers",
    items: ["Suitability analysis results", "Multi-criteria decision analysis maps", "Network centrality maps", "Spatial autocorrelation results", "Hotspot analysis maps", "Predictive urban growth models", "Land change detection maps", "Risk probability maps", "Scenario simulation layers", "Spatial AI prediction outputs"]
  }
];

interface ChatPanelProps {
  mapState: MapState;
  setMapState: React.Dispatch<React.SetStateAction<MapState>>;
}

export function ChatPanel({ mapState, setMapState }: ChatPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "1",
      role: "model",
      content:
        "Hello! I am CartoAI, your advanced spatial analysis and interactive mapping assistant. How can I help you explore or analyze locations today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showCatalog, setShowCatalog] = useState(false);
  const chatRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chatRef.current) {
      chatRef.current = createMainChatSession();
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (textOverride?: string) => {
    const textToSend = textOverride || input;
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: textToSend,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setShowCatalog(false);
    setIsLoading(true);

    try {
      let response = await chatRef.current.sendMessage({
        message: userMsg.content,
      });

      // Handle tool calls
      while (response.functionCalls && response.functionCalls.length > 0) {
        const toolResponses: any[] = [];

        for (const call of response.functionCalls) {
          const { name, args, id } = call;
          console.log(`Tool called: ${name}`, args);

          let result: any = { success: true };

          if (name === "update_map_view") {
            setMapState((s) => ({
              ...s,
              center: [args.lat, args.lng],
              zoom: args.zoom,
            }));
            result = { status: "Map view updated successfully." };
          } else if (name === "add_marker") {
            setMapState((s) => ({
              ...s,
              markers: [
                ...s.markers,
                {
                  id: crypto.randomUUID(),
                  position: [args.lat, args.lng],
                  title: args.title,
                  description: args.description,
                },
              ],
            }));
            result = { status: "Marker added successfully." };
          } else if (name === "add_geojson") {
            try {
              const cleanStr = args.geojson
                .replace(/```json\n/g, "")
                .replace(/```\n?/g, "")
                .trim();
              const parsed = JSON.parse(cleanStr);
              setMapState((s) => ({
                ...s,
                layers: [
                  ...s.layers,
                  {
                    id: crypto.randomUUID(),
                    name: args.name,
                    data: parsed,
                    color: args.color,
                  },
                ],
              }));
              result = { status: "GeoJSON added successfully." };
            } catch (e) {
              result = {
                error: "Invalid GeoJSON format.",
                raw_geojson: args.geojson,
              };
            }
          } else if (name === "clear_map") {
            setMapState((s) => ({ ...s, markers: [], layers: [] }));
            result = { status: "Map cleared successfully." };
          } else if (name === "search_places") {
            const placesStr = await executeSearchPlaces(args.query);
            try {
              const cleanStr = placesStr
                .replace(/```json\n/g, "")
                .replace(/```\n?/g, "")
                .trim();
              const places = JSON.parse(cleanStr);
              // Automatically add markers for these places
              if (Array.isArray(places)) {
                const newMarkers = places.map((p: any) => ({
                  id: crypto.randomUUID(),
                  position: [p.lat, p.lng] as [number, number],
                  title: p.title,
                  description: p.description,
                }));
                setMapState((s) => ({
                  ...s,
                  markers: [...s.markers, ...newMarkers],
                }));

                // If there are places, center map on the first one
                if (places.length > 0) {
                  setMapState((s) => ({
                    ...s,
                    center: [places[0].lat, places[0].lng],
                    zoom: 12,
                  }));
                }
              }
              result = {
                places: places,
                status: "Places found and added to map.",
              };
            } catch (e) {
              result = {
                error: "Failed to parse places data.",
                raw_response: placesStr,
              };
            }
          } else if (name === "search_web") {
            const webResult = await executeSearchWeb(args.query);
            result = { summary: webResult };
          } else if (name === "analyze_site") {
            const analysis = await executeAnalyzeSite(
              args.location,
              args.aspects,
            );
            result = { analysis: analysis };
          }

          toolResponses.push({
            functionResponse: {
              name: name,
              response: result,
            },
          });
        }

        // Send tool responses back to the model
        response = await chatRef.current.sendMessage({
          message: toolResponses,
        });
      }

      const modelMsg: ChatMessage = {
        id: crypto.randomUUID(),
        role: "model",
        content: response.text || "I've completed the task.",
      };
      setMessages((prev) => [...prev, modelMsg]);
    } catch (error: any) {
      console.error("Chat error:", error);
      
      const errorStr = typeof error === 'string' ? error : (error?.message || JSON.stringify(error));
      
      let errorMessage = "Sorry, I encountered an error processing your request.";
      if (errorStr.includes("429") || errorStr.includes("quota") || errorStr.includes("RESOURCE_EXHAUSTED") || errorStr.includes("rate limit")) {
        errorMessage = "I've reached my current API rate limit or quota. Please wait a moment and try again, or check your Gemini API billing details.";
      }

      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "model",
          content: errorMessage,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 border-r border-slate-200 w-full max-w-md shadow-lg z-10 relative">
      <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-500 rounded-lg">
            <MapIcon size={24} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">CartoAI</h1>
            <p className="text-xs text-slate-400 font-medium">
              Spatial Analysis & Mapping
            </p>
          </div>
        </div>
        <button 
          onClick={() => setShowCatalog(!showCatalog)}
          className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-2 text-sm font-medium"
        >
          <Database size={16} />
          Data Catalog
        </button>
      </div>

      {showCatalog && (
        <div className="absolute top-[72px] left-0 right-0 bottom-0 bg-white z-50 overflow-y-auto flex flex-col">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white/90 backdrop-blur-sm">
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <Database size={20} className="text-blue-600" />
              GIS Data Catalog
            </h2>
            <button onClick={() => setShowCatalog(false)} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
              <X size={20} />
            </button>
          </div>
          <div className="p-4 space-y-6">
            <p className="text-sm text-slate-600">
              Click any category to ask CartoAI to find open data sources and plot them on the map.
            </p>
            {DATA_CATEGORIES.map((category, idx) => (
              <div key={idx} className="space-y-2">
                <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">{category.name}</h3>
                <div className="flex flex-wrap gap-2">
                  {category.items.map((item, i) => (
                    <button
                      key={i}
                      onClick={() => handleSend(`Find open GIS data for ${item} in India and plot it on the map.`)}
                      className="px-3 py-1.5 bg-slate-50 border border-slate-200 hover:border-blue-300 hover:bg-blue-50 text-slate-700 text-xs rounded-full transition-colors text-left"
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={cn(
              "flex flex-col",
              msg.role === "user" ? "items-end" : "items-start",
            )}
          >
            <div
              className={cn(
                "max-w-[85%] rounded-2xl p-4 shadow-sm",
                msg.role === "user"
                  ? "bg-blue-600 text-white rounded-tr-sm"
                  : "bg-white border border-slate-200 text-slate-800 rounded-tl-sm",
              )}
            >
              {msg.role === "model" ? (
                <div className="markdown-body prose prose-sm max-w-none prose-p:leading-relaxed prose-pre:bg-slate-100 prose-pre:text-slate-800">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              ) : (
                <p className="text-sm leading-relaxed">{msg.content}</p>
              )}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex items-start">
            <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm p-4 shadow-sm flex items-center gap-3">
              <Loader2 size={18} className="animate-spin text-blue-500" />
              <span className="text-sm text-slate-500 font-medium">
                CartoAI is thinking...
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 bg-white border-t border-slate-200">
        <div className="flex gap-2 mb-3 overflow-x-auto pb-2 scrollbar-hide">
          <button
            onClick={() => handleSend("Show me hospitals in Mumbai")}
            className="whitespace-nowrap px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded-full font-medium transition-colors flex items-center gap-1.5"
          >
            <Search size={14} /> Find places
          </button>
          <button
            onClick={() =>
              handleSend(
                "Analyze the real estate potential of Bandra Kurla Complex, Mumbai",
              )
            }
            className="whitespace-nowrap px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded-full font-medium transition-colors flex items-center gap-1.5"
          >
            <BrainCircuit size={14} /> Site Analysis
          </button>
          <button
            onClick={() => handleSend("Draw a polygon around New Delhi")}
            className="whitespace-nowrap px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded-full font-medium transition-colors flex items-center gap-1.5"
          >
            <Layers size={14} /> Draw GeoJSON
          </button>
        </div>
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Ask anything about any location..."
            className="w-full pl-4 pr-12 py-3 bg-slate-100 border-transparent focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-xl text-sm transition-all outline-none"
            disabled={isLoading}
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || isLoading}
            className="absolute right-2 p-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-lg transition-colors"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
