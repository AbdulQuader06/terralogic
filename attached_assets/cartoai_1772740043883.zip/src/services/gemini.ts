import {
  GoogleGenAI,
  Type,
  FunctionDeclaration,
  GenerateContentResponse,
  ThinkingLevel,
} from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

// Tool Definitions for the Main Model
export const updateMapViewTool: FunctionDeclaration = {
  name: "update_map_view",
  description:
    "Updates the map view to center on a specific latitude and longitude with a given zoom level.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      lat: { type: Type.NUMBER, description: "Latitude" },
      lng: { type: Type.NUMBER, description: "Longitude" },
      zoom: {
        type: Type.NUMBER,
        description: "Zoom level (1-20, 10 is city level, 15 is street level)",
      },
    },
    required: ["lat", "lng", "zoom"],
  },
};

export const addMarkerTool: FunctionDeclaration = {
  name: "add_marker",
  description: "Adds a marker to the map at a specific location.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      lat: { type: Type.NUMBER, description: "Latitude" },
      lng: { type: Type.NUMBER, description: "Longitude" },
      title: { type: Type.STRING, description: "Title of the marker" },
      description: {
        type: Type.STRING,
        description: "Description of the marker (optional)",
      },
    },
    required: ["lat", "lng", "title"],
  },
};

export const addGeojsonTool: FunctionDeclaration = {
  name: "add_geojson",
  description:
    "Adds GeoJSON data to the map. Use this to draw polygons, lines, or complex features.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING, description: "Name of the layer" },
      geojson: {
        type: Type.STRING,
        description: "Valid GeoJSON string representation",
      },
      color: {
        type: Type.STRING,
        description: "Hex color code for the feature (optional)",
      },
    },
    required: ["name", "geojson"],
  },
};

export const clearMapTool: FunctionDeclaration = {
  name: "clear_map",
  description: "Clears all markers and GeoJSON layers from the map.",
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

export const searchPlacesTool: FunctionDeclaration = {
  name: "search_places",
  description:
    "Searches for places using Google Maps data. Returns a list of places with their coordinates and details.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description:
          "The search query (e.g., 'coffee shops in Mumbai', 'hospitals near Delhi')",
      },
    },
    required: ["query"],
  },
};

export const searchWebTool: FunctionDeclaration = {
  name: "search_web",
  description:
    "Searches the web for up-to-date information, news, or general knowledge.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: { type: Type.STRING, description: "The search query" },
    },
    required: ["query"],
  },
};

export const analyzeSiteTool: FunctionDeclaration = {
  name: "analyze_site",
  description:
    "Performs a deep, complex site evaluation or spatial analysis using high-level reasoning.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      location: { type: Type.STRING, description: "The location to analyze" },
      aspects: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
        description:
          "Aspects to analyze (e.g., 'demographics', 'zoning', 'mobility', 'risks')",
      },
    },
    required: ["location", "aspects"],
  },
};

// Secondary Model Functions

export async function executeSearchPlaces(query: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Find places matching this query: ${query}. Return a JSON array of objects, each with 'title', 'lat', 'lng', and 'description'. Do not use markdown blocks, just raw JSON.`,
      config: {
        tools: [{ googleMaps: {} }],
      },
    });
    let text = response.text || "[]";
    text = text
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .trim();
    return text;
  } catch (e: any) {
    console.error("Error searching places:", e);
    const errorStr = typeof e === 'string' ? e : (e?.message || JSON.stringify(e));
    if (errorStr.includes("429") || errorStr.includes("quota") || errorStr.includes("RESOURCE_EXHAUSTED") || errorStr.includes("rate limit")) {
      return JSON.stringify({ error: "API quota exceeded. Please try again later." });
    }
    return JSON.stringify({ error: "Failed to search places" });
  }
}

export async function executeSearchWeb(query: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search the web for: ${query}. Provide a concise summary of the findings.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    return response.text || "No results found.";
  } catch (e: any) {
    console.error("Error searching web:", e);
    const errorStr = typeof e === 'string' ? e : (e?.message || JSON.stringify(e));
    if (errorStr.includes("429") || errorStr.includes("quota") || errorStr.includes("RESOURCE_EXHAUSTED") || errorStr.includes("rate limit")) {
      return "API quota exceeded. Please try again later.";
    }
    return "Failed to search the web.";
  }
}

export async function executeAnalyzeSite(
  location: string,
  aspects: string[],
): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: `Perform a detailed site evaluation for ${location}. Focus on these aspects: ${aspects.join(", ")}. Provide a structured, professional report suitable for real estate or urban planning.`,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
      },
    });
    return response.text || "Analysis failed.";
  } catch (e: any) {
    console.error("Error analyzing site:", e);
    const errorStr = typeof e === 'string' ? e : (e?.message || JSON.stringify(e));
    if (errorStr.includes("429") || errorStr.includes("quota") || errorStr.includes("RESOURCE_EXHAUSTED") || errorStr.includes("rate limit")) {
      return "API quota exceeded. Please try again later.";
    }
    return "Failed to analyze site.";
  }
}

// Main Chat Session
export function createMainChatSession() {
  return ai.chats.create({
    model: "gemini-3.1-pro-preview",
    config: {
      systemInstruction: `You are CartoAI, a highly advanced spatial analysis and interactive mapping assistant, and a comprehensive hub of GIS knowledge.
Your primary focus is on India, but you can handle global queries.
You help users with site evaluation, urban planning, real estate analysis, and general geographic queries.
You have access to tools to control an interactive map.

CRITICAL: You are a hub of all GIS knowledge found online. You are explicitly trained to find and provide open data sources for the following categories:
- Terrain & Physical Geography: Elevation (DEM), Slope, Aspect, Terrain ruggedness, Landforms, Contours, Watersheds, Drainage basins, Soil type, Soil fertility.
- Hydrology & Water Systems: Rivers, Streams, Lakes, Reservoirs, Wetlands, Flood risk zones, Floodplains, Groundwater aquifers, Water table depth, Drainage networks.
- Climate & Environmental Conditions: Rainfall distribution, Temperature distribution, Wind patterns, Solar radiation, Air pollution levels, Noise pollution, Heat island zones, Climate zones, Drought risk, Storm paths.
- Land & Ecology: Land use, Land cover, Forest cover, Deforestation areas, Biodiversity hotspots, Wildlife habitats, Protected areas, National parks, Mangroves, Grasslands.
- Agriculture & Rural Data: Cropland distribution, Crop types, Irrigation networks, Agricultural productivity, Soil moisture, Pasture lands, Agricultural suitability, Farm boundaries, Plantation areas, Livestock density.
- Urban & Built Environment: Infrastructure, Building footprints, Building heights, Land parcels/property boundaries, Zoning areas, Residential areas, Commercial areas, Industrial zones, Slums/informal settlements, Urban density.
- Transportation & Mobility: Road networks, Railways, Metro systems, Bus routes, Bus stops, Airports, Ports/harbors, Bicycle lanes, Pedestrian pathways, Traffic congestion data.
- Public Services & Facilities: Schools, Colleges/universities, Hospitals, Clinics, Fire stations, Police stations, Government buildings, Community centers, Libraries, Parks and recreational areas.
- Utilities & Infrastructure Networks: Water supply pipelines, Sewer networks, Stormwater drainage, Electricity grid lines, Power substations, Gas pipelines, Telecommunication towers, Internet fiber networks, Waste collection zones, Landfills/waste treatment plants.
- Risk, Hazards & Social Data: Landslide risk zones, Earthquake hazard zones, Coastal erosion zones, Tsunami risk areas, Fire risk zones, Crime distribution, Population density, Demographic distribution (age, gender), Economic activity zones, Poverty/deprivation zones.
- Urban Form & Building Data: Floor area ratio (FAR), Building age, Building construction type, Roof type, Roof materials, Building energy consumption, Historical buildings, Vacant buildings, Under-construction buildings, Urban skyline profile.
- Urban Planning & Development: Master plan zones, Development control zones, Future land use plans, Redevelopment zones, Urban growth boundaries, Special economic zones, Smart city project areas, Transit-oriented development zones, Mixed-use development zones, Land value zones.
- Transportation & Mobility Analytics: Travel time surfaces, Accessibility to public transport, Commuting patterns, Origin-destination travel flows, Parking availability zones, Electric vehicle charging stations, Traffic accident hotspots, Ride-sharing pickup zones, Logistics hubs, Freight routes.
- Utilities & Urban Services: Water demand zones, Electricity demand zones, Internet coverage quality, Mobile network signal strength, Street lighting coverage, Smart sensors / IoT networks, Waste recycling centers, Waste generation zones, Stormwater retention basins, Urban drainage capacity.
- Environmental Monitoring: Tree canopy coverage, Urban green corridors, Urban biodiversity zones, Air quality monitoring stations, Carbon emission distribution, Noise monitoring stations, Soil contamination zones, Brownfield sites, Environmental remediation sites, Ecological restoration zones.
- Climate Adaptation & Sustainability: Sea level rise risk areas, Coastal flood projections, Urban heat vulnerability, Cooling corridors, Renewable energy potential zones, Solar rooftop potential, Wind energy potential, Carbon sequestration areas, Climate resilience zones, Green infrastructure networks.
- Public Health & Social Infrastructure: Disease outbreak hotspots, Health accessibility zones, Emergency response times, Ambulance coverage areas, Vaccination coverage zones, Food deserts, Nutrition access zones, Childcare facilities, Elder care facilities, Disability accessibility infrastructure.
- Economic & Commercial Activity: Business density, Retail clusters, Industrial output zones, Commercial footfall zones, Tourism hotspots, Night-time economy zones, Market areas, Property price distribution, Rental value zones, Employment density.
- Cultural & Social Spaces: Religious institutions, Cultural heritage sites, Museums and galleries, Festivals and event zones, Public art installations, Historical districts, Film shooting locations, Cultural tourism routes, Community gathering spaces, Traditional craft clusters.
- Advanced Spatial Analytics Layers: Suitability analysis results, Multi-criteria decision analysis maps, Network centrality maps, Spatial autocorrelation results, Hotspot analysis maps, Predictive urban growth models, Land change detection maps, Risk probability maps, Scenario simulation layers, Spatial AI prediction outputs.

When a user asks for data in any of these categories, you MUST:
1. Use the 'search_web' tool to find open data sources (e.g., OpenCity.in, Data.gov.in, SEDAC, OpenStreetMap, local municipal portals, Bhuvan, NASA Earth Data, USGS EarthExplorer).
2. If you find or know the data, use the 'add_geojson' tool to generate and plot an approximate or exact GeoJSON representation of that data on the map.
3. Provide the user with links to the original open data sources (KML/GeoJSON/CSV/JSON/Shapefile) so they can download the raw data themselves.
4. If the data is too complex to generate fully, generate a simplified bounding box or representative points using 'add_geojson' or 'add_marker' and explain what it represents.

When a user asks to see something on the map, use the appropriate tools to update the view, add markers, or add GeoJSON.
If you need to find specific places (e.g., "show me hospitals in Mumbai"), use the 'search_places' tool, then use the results to add markers to the map.
If the user asks for a complex site evaluation or deep analysis, use the 'analyze_site' tool.
Always be helpful, professional, and concise.
When you add markers or geojson, tell the user what you added.`,
      tools: [
        {
          functionDeclarations: [
            updateMapViewTool,
            addMarkerTool,
            addGeojsonTool,
            clearMapTool,
            searchPlacesTool,
            searchWebTool,
            analyzeSiteTool,
          ],
        },
      ],
    },
  });
}

// Fast Chat Session (for quick responses if needed, though we'll stick to pro for the main loop for simplicity and tool calling reliability)
export async function generateFastResponse(prompt: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-lite-preview",
    contents: prompt,
  });
  return response.text || "";
}
