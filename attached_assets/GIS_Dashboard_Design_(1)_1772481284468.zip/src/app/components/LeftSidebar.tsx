import { Search, Sun, Mountain, Wind, Trees, Droplets, Map, Layers, Bot, Send } from "lucide-react";
import { Switch } from "@radix-ui/react-switch";
import { useState } from "react";

interface Layer {
  id: string;
  name: string;
  icon: React.ReactNode;
  enabled: boolean;
  color: string;
}

interface LeftSidebarProps {
  layers: Layer[];
  onToggleLayer: (layerId: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export function LeftSidebar({ layers, onToggleLayer, searchQuery, onSearchChange }: LeftSidebarProps) {
  const [activeTab, setActiveTab] = useState<"layers" | "chat">("layers");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hello! I'm your AI urban planning assistant. Ask me about site analysis, zoning, environmental factors, or urban design recommendations.",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputMessage,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: generateAIResponse(inputMessage),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
    }, 500);

    setInputMessage("");
  };

  const generateAIResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes("solar") || lowerQuery.includes("sun")) {
      return "Based on the current site analysis, the solar exposure is excellent with high south-facing potential. I recommend positioning solar panels at a 30° angle for optimal energy capture. Expected ROI is 6-8 years.";
    } else if (lowerQuery.includes("flood") || lowerQuery.includes("water")) {
      return "The flood risk assessment shows low vulnerability due to elevated terrain. Standard drainage systems should be sufficient, but consider implementing bioswales for sustainable water management.";
    } else if (lowerQuery.includes("zoning") || lowerQuery.includes("building")) {
      return "This area is zoned for mixed-use development with a maximum height restriction of 45 meters. Ground floor commercial with residential units above would be ideal for this location.";
    } else if (lowerQuery.includes("wind")) {
      return "Wind exposure is moderate at this site. Consider wind barriers for outdoor spaces and position building openings perpendicular to prevailing winds for natural ventilation.";
    } else if (lowerQuery.includes("soil") || lowerQuery.includes("foundation")) {
      return "Soil analysis indicates good bearing capacity with minimal settlement risk. Standard foundation types are suitable, though I recommend a geotechnical survey for structures over 10 stories.";
    } else {
      return "I can help you analyze various aspects of this site including solar potential, flood risk, zoning regulations, soil conditions, and wind patterns. What specific information would you like to know?";
    }
  };

  return (
    <div className="w-80 bg-[#0f1014] border-r border-[#1e1f24] flex flex-col">
      {/* Project Info */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h2 className="text-white text-lg mb-1">Project Overview</h2>
        <p className="text-gray-500 text-sm">Urban analysis & site intelligence</p>
      </div>

      {/* Search Location */}
      <div className="p-6 border-b border-[#1e1f24]">
        <label className="text-gray-300 text-sm mb-2 block">Search Location</label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Enter coordinates or address..."
            className="w-full bg-[#14151a] border border-[#2a2b30] rounded-md pl-10 pr-4 py-2.5 text-sm text-gray-300 placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
          />
        </div>
      </div>

      {/* Tabbed Content Area */}
      <div className="flex-1 overflow-y-auto p-6 flex flex-col">
        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          <button
            onClick={() => setActiveTab("layers")}
            className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-all ${
              activeTab === "layers"
                ? "bg-emerald-600 text-white"
                : "bg-[#14151a] text-gray-400 hover:text-gray-300"
            }`}
          >
            <Layers className="w-4 h-4" />
            Data Layers
          </button>
          <button
            onClick={() => setActiveTab("chat")}
            className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-all ${
              activeTab === "chat"
                ? "bg-emerald-600 text-white"
                : "bg-[#14151a] text-gray-400 hover:text-gray-300"
            }`}
          >
            <Bot className="w-4 h-4" />
            AI Assistant
          </button>
        </div>

        {/* Data Layers Tab */}
        {activeTab === "layers" && (
          <>
            <h3 className="text-gray-300 text-sm mb-4">Active Data Layers</h3>
            <div className="space-y-2">
              {layers.map((layer) => (
                <div
                  key={layer.id}
                  className="flex items-center justify-between p-3 bg-[#14151a] border border-[#2a2b30] rounded-lg hover:border-[#3a3b40] transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-md ${layer.enabled ? layer.color : "bg-[#1e1f24]"}`}>
                      <div className={layer.enabled ? "text-white" : "text-gray-600"}>
                        {layer.icon}
                      </div>
                    </div>
                    <span className={`text-sm ${layer.enabled ? "text-white" : "text-gray-500"}`}>
                      {layer.name}
                    </span>
                  </div>
                  <Switch
                    checked={layer.enabled}
                    onCheckedChange={() => onToggleLayer(layer.id)}
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                      layer.enabled ? "bg-emerald-600" : "bg-[#2a2b30]"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        layer.enabled ? "translate-x-5" : "translate-x-0.5"
                      }`}
                    />
                  </Switch>
                </div>
              ))}
            </div>
          </>
        )}

        {/* AI Chat Tab */}
        {activeTab === "chat" && (
          <div className="flex flex-col h-full">
            <h3 className="text-gray-300 text-sm mb-4">Urban Planning Assistant</h3>
            
            {/* Messages */}
            <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  {message.role === "assistant" && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-600 flex items-center justify-center">
                      <Bot className="w-4 h-4 text-white" />
                    </div>
                  )}
                  <div
                    className={`max-w-[200px] p-3 rounded-lg text-xs ${
                      message.role === "user"
                        ? "bg-emerald-600 text-white"
                        : "bg-[#14151a] border border-[#2a2b30] text-gray-300"
                    }`}
                  >
                    {message.content}
                  </div>
                  {message.role === "user" && (
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                      <span className="text-xs text-white">You</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="mt-auto">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                  placeholder="Ask about site analysis..."
                  className="flex-1 bg-[#14151a] border border-[#2a2b30] rounded-md px-3 py-2 text-sm text-gray-300 placeholder-gray-600 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
                />
                <button
                  onClick={handleSendMessage}
                  className="p-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                Ask about solar, wind, zoning, or soil conditions
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Stats Footer */}
      <div className="p-6 border-t border-[#1e1f24] bg-[#0a0b0e]">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-gray-500 text-xs mb-1">Active Layers</div>
            <div className="text-white text-lg">{layers.filter(l => l.enabled).length}/{layers.length}</div>
          </div>
          <div>
            <div className="text-gray-500 text-xs mb-1">Analysis Ready</div>
            <div className="text-emerald-400 text-lg">✓</div>
          </div>
        </div>
      </div>
    </div>
  );
}