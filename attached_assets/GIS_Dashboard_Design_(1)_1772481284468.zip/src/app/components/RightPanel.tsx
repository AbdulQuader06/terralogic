import { TrendingUp, AlertTriangle, CheckCircle2, MapPin, Mountain, Sun, Wind, Droplets, Building2, Activity } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

interface LocationData {
  lat: number;
  lng: number;
  elevation: number;
  zoning: string;
  sunExposure: number;
  soilSuitability: number;
  floodRisk: string;
  windExposure: number;
}

interface RightPanelProps {
  locationData: LocationData | null;
}

const elevationData = [
  { x: "0m", elevation: 245 },
  { x: "50m", elevation: 248 },
  { x: "100m", elevation: 252 },
  { x: "150m", elevation: 258 },
  { x: "200m", elevation: 265 },
  { x: "250m", elevation: 268 },
];

const suitabilityData = [
  { metric: "Solar", value: 85 },
  { metric: "Soil", value: 72 },
  { metric: "Wind", value: 65 },
  { metric: "Water", value: 78 },
  { metric: "Access", value: 90 },
];

// Calculate overall suitability score
function calculateSuitabilityScore(locationData: LocationData): number {
  const weights = {
    sunExposure: 0.25,
    soilSuitability: 0.25,
    windExposure: 0.2,
    floodRisk: 0.3,
  };

  const floodRiskScore = locationData.floodRisk === "Low" ? 90 : locationData.floodRisk === "Moderate" ? 60 : 30;
  
  const score =
    locationData.sunExposure * weights.sunExposure +
    locationData.soilSuitability * weights.soilSuitability +
    locationData.windExposure * weights.windExposure +
    floodRiskScore * weights.floodRisk;

  return Math.round(score);
}

// Get score rating text and color
function getScoreRating(score: number): { text: string; color: string; bgColor: string } {
  if (score >= 85) return { text: "Excellent", color: "text-emerald-400", bgColor: "bg-emerald-500" };
  if (score >= 70) return { text: "Good", color: "text-green-400", bgColor: "bg-green-500" };
  if (score >= 55) return { text: "Fair", color: "text-yellow-400", bgColor: "bg-yellow-500" };
  return { text: "Poor", color: "text-red-400", bgColor: "bg-red-500" };
}

// Calculate development density (mock data, will use real SDK data later)
function calculateDevelopmentDensity(locationData: LocationData): { level: string; percentage: number; color: string } {
  // This would be replaced with real map SDK data
  // For now, generate based on coordinates
  const mockDensity = Math.abs(Math.sin(locationData.lat) * Math.cos(locationData.lng)) * 100;
  
  if (mockDensity >= 75) return { level: "High Density", percentage: mockDensity, color: "bg-purple-500" };
  if (mockDensity >= 50) return { level: "Medium Density", percentage: mockDensity, color: "bg-blue-500" };
  if (mockDensity >= 25) return { level: "Low Density", percentage: mockDensity, color: "bg-cyan-500" };
  return { level: "Rural", percentage: mockDensity, color: "bg-green-500" };
}

export function RightPanel({ locationData }: RightPanelProps) {
  if (!locationData) {
    return (
      <div className="w-96 bg-[#0f1014] border-l border-[#1e1f24] flex items-center justify-center p-6">
        <div className="text-center">
          <MapPin className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <h3 className="text-gray-400 text-sm mb-1">No Location Selected</h3>
          <p className="text-gray-600 text-xs">Click on the map to analyze a location</p>
        </div>
      </div>
    );
  }

  const suitabilityScore = calculateSuitabilityScore(locationData);
  const scoreRating = getScoreRating(suitabilityScore);
  const developmentDensity = calculateDevelopmentDensity(locationData);

  return (
    <div className="w-96 bg-[#0f1014] border-l border-[#1e1f24] overflow-y-auto">
      {/* Header */}
      <div className="p-6 border-b border-[#1e1f24] bg-gradient-to-br from-emerald-600/10 to-transparent">
        <h2 className="text-white text-lg mb-1">AI Site Analysis</h2>
        <p className="text-gray-400 text-xs">Real-time intelligence & recommendations</p>
      </div>

      {/* Overall Suitability Score */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h3 className="text-gray-300 text-sm mb-4">Overall Site Suitability</h3>
        <div className="bg-gradient-to-br from-emerald-600/10 to-transparent border border-emerald-500/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-3xl font-bold text-white mb-1">{suitabilityScore}/100</div>
              <div className={`text-sm ${scoreRating.color}`}>{scoreRating.text} Location</div>
            </div>
            <div className="relative w-20 h-20">
              {/* Circular progress */}
              <svg className="transform -rotate-90 w-20 h-20">
                <circle
                  cx="40"
                  cy="40"
                  r="32"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="transparent"
                  className="text-[#2a2b30]"
                />
                <circle
                  cx="40"
                  cy="40"
                  r="32"
                  stroke="currentColor"
                  strokeWidth="6"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 32}`}
                  strokeDashoffset={`${2 * Math.PI * 32 * (1 - suitabilityScore / 100)}`}
                  className={scoreRating.color.replace('text-', 'text-')}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <Activity className={`w-6 h-6 ${scoreRating.color}`} />
              </div>
            </div>
          </div>
          
          {/* Score breakdown bar */}
          <div className="h-2 bg-[#1e1f24] rounded-full overflow-hidden">
            <div
              className={`h-full ${scoreRating.bgColor} transition-all duration-500`}
              style={{ width: `${suitabilityScore}%` }}
            />
          </div>
          
          <div className="mt-3 text-xs text-gray-400">
            Based on environmental metrics, zoning, and site conditions
          </div>
        </div>
      </div>

      {/* Development Density Indicator */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h3 className="text-gray-300 text-sm mb-4">Development Density Analysis</h3>
        <div className="bg-[#14151a] border border-[#2a2b30] rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-md ${developmentDensity.color}`}>
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-sm text-white mb-0.5">{developmentDensity.level}</div>
                <div className="text-xs text-gray-400">Urban Development Index</div>
              </div>
            </div>
            <div className="text-xl text-white">{Math.round(developmentDensity.percentage)}%</div>
          </div>
          
          {/* Density bar */}
          <div className="h-2 bg-[#1e1f24] rounded-full overflow-hidden">
            <div
              className={`h-full ${developmentDensity.color} transition-all duration-500`}
              style={{ width: `${developmentDensity.percentage}%` }}
            />
          </div>
          
          <div className="mt-3 pt-3 border-t border-[#2a2b30] text-xs text-gray-400">
            <div className="flex items-center justify-between">
              <span>Building Footprint:</span>
              <span className="text-gray-300">{Math.round(developmentDensity.percentage * 0.6)}%</span>
            </div>
            <div className="flex items-center justify-between mt-1">
              <span>Infrastructure Coverage:</span>
              <span className="text-gray-300">{Math.round(developmentDensity.percentage * 0.8)}%</span>
            </div>
          </div>
          
          <div className="mt-3 text-xs text-gray-500 italic">
            * Will integrate with map SDK for real-time building data
          </div>
        </div>
      </div>

      {/* Location Details */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h3 className="text-gray-300 text-sm mb-4">Site Information</h3>
        <div className="space-y-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span className="text-xs text-gray-500">Coordinates</span>
            </div>
            <div className="text-right">
              <div className="text-xs text-white">{locationData.lat.toFixed(6)}</div>
              <div className="text-xs text-white">{locationData.lng.toFixed(6)}</div>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mountain className="w-4 h-4 text-gray-500" />
              <span className="text-xs text-gray-500">Elevation</span>
            </div>
            <span className="text-xs text-white">{locationData.elevation}m ASL</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span className="text-xs text-gray-500">Zoning</span>
            </div>
            <span className="text-xs text-emerald-400">{locationData.zoning}</span>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h3 className="text-gray-300 text-sm mb-4">Environmental Metrics</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-[#14151a] border border-[#2a2b30] rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Sun className="w-4 h-4 text-yellow-500" />
              <span className="text-xs text-gray-400">Sun Exposure</span>
            </div>
            <div className="text-xl text-white">{locationData.sunExposure}%</div>
            <div className="h-1.5 bg-[#1e1f24] rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-yellow-500 rounded-full"
                style={{ width: `${locationData.sunExposure}%` }}
              />
            </div>
          </div>
          <div className="bg-[#14151a] border border-[#2a2b30] rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Mountain className="w-4 h-4 text-green-500" />
              <span className="text-xs text-gray-400">Soil Quality</span>
            </div>
            <div className="text-xl text-white">{locationData.soilSuitability}%</div>
            <div className="h-1.5 bg-[#1e1f24] rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-green-500 rounded-full"
                style={{ width: `${locationData.soilSuitability}%` }}
              />
            </div>
          </div>
          <div className="bg-[#14151a] border border-[#2a2b30] rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Wind className="w-4 h-4 text-blue-400" />
              <span className="text-xs text-gray-400">Wind Exposure</span>
            </div>
            <div className="text-xl text-white">{locationData.windExposure}%</div>
            <div className="h-1.5 bg-[#1e1f24] rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-blue-400 rounded-full"
                style={{ width: `${locationData.windExposure}%` }}
              />
            </div>
          </div>
          <div className="bg-[#14151a] border border-[#2a2b30] rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Droplets className="w-4 h-4 text-cyan-400" />
              <span className="text-xs text-gray-400">Flood Risk</span>
            </div>
            <div className={`text-xl ${locationData.floodRisk === "Low" ? "text-green-400" : "text-yellow-400"}`}>
              {locationData.floodRisk}
            </div>
          </div>
        </div>
      </div>

      {/* Elevation Profile Chart */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h3 className="text-gray-300 text-sm mb-4">Elevation Profile</h3>
        <div className="h-32 bg-[#14151a] border border-[#2a2b30] rounded-lg p-3">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={elevationData}>
              <defs>
                <linearGradient id="elevationGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="x"
                stroke="#4a4b50"
                tick={{ fill: "#6b7280", fontSize: 10 }}
                axisLine={false}
              />
              <YAxis
                stroke="#4a4b50"
                tick={{ fill: "#6b7280", fontSize: 10 }}
                axisLine={false}
                domain={[240, 270]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#14151a",
                  border: "1px solid #2a2b30",
                  borderRadius: "6px",
                  fontSize: "12px",
                }}
              />
              <Area
                type="monotone"
                dataKey="elevation"
                stroke="#10b981"
                strokeWidth={2}
                fill="url(#elevationGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Site Suitability Radar */}
      <div className="p-6 border-b border-[#1e1f24]">
        <h3 className="text-gray-300 text-sm mb-4">Site Suitability Analysis</h3>
        <div className="h-56 bg-[#14151a] border border-[#2a2b30] rounded-lg p-3">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={suitabilityData}>
              <PolarGrid stroke="#2a2b30" />
              <PolarAngleAxis
                dataKey="metric"
                tick={{ fill: "#9ca3af", fontSize: 11 }}
              />
              <PolarRadiusAxis
                angle={90}
                domain={[0, 100]}
                tick={{ fill: "#6b7280", fontSize: 10 }}
              />
              <Radar
                name="Suitability"
                dataKey="value"
                stroke="#10b981"
                fill="#10b981"
                fillOpacity={0.3}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Recommendations */}
      <div className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <h3 className="text-gray-300 text-sm">AI Recommendations</h3>
        </div>
        <div className="space-y-3">
          <div className="flex items-start gap-3 p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-xs text-emerald-300 mb-1">Excellent Solar Potential</div>
              <div className="text-xs text-gray-400">
                Consider south-facing solar panels. Expected ROI: 6-8 years
              </div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-yellow-500/5 border border-yellow-500/20 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-xs text-yellow-300 mb-1">Wind Exposure Considerations</div>
              <div className="text-xs text-gray-400">
                Moderate wind speeds. Recommend wind barriers for outdoor spaces
              </div>
            </div>
          </div>
          <div className="flex items-start gap-3 p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg">
            <CheckCircle2 className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-xs text-blue-300 mb-1">Low Flood Risk</div>
              <div className="text-xs text-gray-400">
                Site elevation provides natural protection. Standard drainage sufficient
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}