import { useEffect, useRef, useState } from "react";
import { MapPin, Plus, Minus, Maximize2 } from "lucide-react";

interface MapCanvasProps {
  selectedLocation: { lat: number; lng: number } | null;
  onMapClick: (lat: number, lng: number) => void;
  center: [number, number];
  zoom: number;
}

export function MapCanvas({ selectedLocation, onMapClick, center, zoom }: MapCanvasProps) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [currentZoom, setCurrentZoom] = useState(zoom);
  const [isDragging, setIsDragging] = useState(false);

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isDragging) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Convert pixel coordinates to lat/lng (simplified calculation)
    const lat = center[0] + ((rect.height / 2 - y) / rect.height) * 0.1 * (1 / currentZoom);
    const lng = center[1] + ((x - rect.width / 2) / rect.width) * 0.1 * (1 / currentZoom);
    
    onMapClick(lat, lng);
  };

  const handleZoomIn = () => {
    setCurrentZoom(prev => Math.min(prev + 1, 18));
  };

  const handleZoomOut = () => {
    setCurrentZoom(prev => Math.max(prev - 1, 3));
  };

  return (
    <div className="relative w-full h-full bg-[#0f1014]">
      {/* Map Controls Overlay */}
      <div className="absolute top-4 left-4 z-[1000] flex gap-2">
        <div className="bg-[#0a0b0e]/95 backdrop-blur-sm border border-[#2a2b30] rounded-lg px-3 py-2">
          <span className="text-xs text-gray-400">Zoom: {currentZoom}</span>
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
        <button
          onClick={handleZoomIn}
          className="bg-[#0a0b0e]/95 backdrop-blur-sm border border-[#2a2b30] rounded-lg p-2 hover:bg-[#14151a] transition-colors"
        >
          <Plus className="w-4 h-4 text-gray-300" />
        </button>
        <button
          onClick={handleZoomOut}
          className="bg-[#0a0b0e]/95 backdrop-blur-sm border border-[#2a2b30] rounded-lg p-2 hover:bg-[#14151a] transition-colors"
        >
          <Minus className="w-4 h-4 text-gray-300" />
        </button>
        <button className="bg-[#0a0b0e]/95 backdrop-blur-sm border border-[#2a2b30] rounded-lg p-2 hover:bg-[#14151a] transition-colors">
          <Maximize2 className="w-4 h-4 text-gray-300" />
        </button>
      </div>

      {/* Map Canvas */}
      <div
        ref={canvasRef}
        onClick={handleCanvasClick}
        onMouseDown={() => setIsDragging(false)}
        onMouseMove={() => setIsDragging(true)}
        onMouseUp={() => setTimeout(() => setIsDragging(false), 50)}
        className="w-full h-full cursor-crosshair relative overflow-hidden"
        style={{
          backgroundImage: `
            linear-gradient(rgba(16, 185, 129, 0.05) 1px, transparent 1px),
            linear-gradient(90deg, rgba(16, 185, 129, 0.05) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px',
          backgroundColor: '#0f1014'
        }}
      >
        {/* Grid overlay with topographic feel */}
        <div className="absolute inset-0 opacity-20">
          <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
                <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#10b981" strokeWidth="0.5" opacity="0.3"/>
              </pattern>
              <radialGradient id="mapGradient">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#0f1014" stopOpacity="0" />
              </radialGradient>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Urban features visualization */}
        <div className="absolute inset-0">
          {/* Simulated urban blocks */}
          <div className="absolute top-[20%] left-[15%] w-32 h-24 border-2 border-emerald-500/30 bg-emerald-500/5 rounded"></div>
          <div className="absolute top-[40%] left-[25%] w-40 h-32 border-2 border-blue-500/30 bg-blue-500/5 rounded"></div>
          <div className="absolute top-[60%] left-[40%] w-36 h-28 border-2 border-yellow-500/30 bg-yellow-500/5 rounded"></div>
          <div className="absolute top-[30%] right-[20%] w-44 h-36 border-2 border-purple-500/30 bg-purple-500/5 rounded"></div>
          <div className="absolute bottom-[20%] right-[30%] w-32 h-24 border-2 border-cyan-500/30 bg-cyan-500/5 rounded"></div>
          
          {/* Simulated roads */}
          <div className="absolute top-[50%] left-0 right-0 h-0.5 bg-gray-500/30"></div>
          <div className="absolute top-0 bottom-0 left-[50%] w-0.5 bg-gray-500/30"></div>
          <div className="absolute top-[25%] left-0 right-0 h-0.5 bg-gray-500/20"></div>
          <div className="absolute top-[75%] left-0 right-0 h-0.5 bg-gray-500/20"></div>
          <div className="absolute top-0 bottom-0 left-[25%] w-0.5 bg-gray-500/20"></div>
          <div className="absolute top-0 bottom-0 left-[75%] w-0.5 bg-gray-500/20"></div>
        </div>

        {/* Center marker */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
          <div className="absolute -inset-8 border border-emerald-400/30 rounded-full"></div>
        </div>

        {/* Selected location marker */}
        {selectedLocation && (
          <div 
            className="absolute -translate-x-1/2 -translate-y-full"
            style={{
              left: `${50 + ((selectedLocation.lng - center[1]) / 0.1) * 100 * currentZoom}%`,
              top: `${50 - ((selectedLocation.lat - center[0]) / 0.1) * 100 * currentZoom}%`
            }}
          >
            <MapPin className="w-8 h-8 text-emerald-400 drop-shadow-lg animate-bounce" fill="currentColor" />
            <div className="absolute -inset-4 bg-emerald-400/20 rounded-full blur-xl"></div>
          </div>
        )}

        {/* Location info overlay */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-[#0a0b0e]/95 backdrop-blur-sm border border-[#2a2b30] rounded-lg px-4 py-2 z-[999]">
          <div className="text-xs text-gray-400">
            <span className="text-emerald-400">{center[0].toFixed(4)}°N</span>
            {" / "}
            <span className="text-emerald-400">{center[1].toFixed(4)}°E</span>
          </div>
        </div>

        {/* Click instruction */}
        {!selectedLocation && (
          <div className="absolute bottom-1/3 left-1/2 -translate-x-1/2 text-center pointer-events-none">
            <div className="bg-[#0a0b0e]/95 backdrop-blur-sm border border-emerald-500/30 rounded-lg px-6 py-3">
              <MapPin className="w-6 h-6 text-emerald-400 mx-auto mb-2" />
              <p className="text-sm text-gray-300">Click anywhere to analyze</p>
              <p className="text-xs text-gray-500 mt-1">AI site intelligence will appear on the right</p>
            </div>
          </div>
        )}
      </div>

      {/* Legend Overlay */}
      <div className="absolute bottom-4 left-4 z-[1000] bg-[#0a0b0e]/95 backdrop-blur-sm border border-[#2a2b30] rounded-lg p-4 max-w-xs">
        <div className="text-xs text-gray-400 mb-2">Map Legend</div>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span className="text-xs text-gray-300">High Sun Exposure</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span className="text-xs text-gray-300">Flood Risk Zone</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-xs text-gray-300">Suitable Soil</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-purple-500"></div>
            <span className="text-xs text-gray-300">Urban Development</span>
          </div>
        </div>
      </div>
    </div>
  );
}
