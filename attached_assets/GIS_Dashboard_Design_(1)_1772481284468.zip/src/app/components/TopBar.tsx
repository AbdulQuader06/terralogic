import { Building2, Download, ChevronDown } from "lucide-react";

interface TopBarProps {
  currentProject: string;
  showCaseStudy: boolean;
  onToggleCaseStudy: () => void;
}

export function TopBar({ currentProject, showCaseStudy, onToggleCaseStudy }: TopBarProps) {
  return (
    <div className="h-16 bg-[#0a0b0e] border-b border-[#1e1f24] flex items-center justify-between px-6">
      {/* Logo Section */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Building2 className="w-7 h-7 text-emerald-400" />
          <span className="text-lg text-white tracking-tight">UrbanPreDesign</span>
        </div>
        <div className="h-6 w-px bg-[#2a2b30]" />
        <div className="flex items-center gap-2 bg-[#14151a] px-3 py-1.5 rounded-md border border-[#2a2b30] cursor-pointer hover:border-[#3a3b40] transition-colors">
          <span className="text-sm text-gray-300">{currentProject}</span>
          <ChevronDown className="w-4 h-4 text-gray-500" />
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleCaseStudy}
          className={`px-4 py-2 rounded-md text-sm transition-all ${
            showCaseStudy
              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : "bg-[#14151a] text-gray-400 border border-[#2a2b30] hover:border-[#3a3b40]"
          }`}
        >
          {showCaseStudy ? "✓ Hyderabad Case Study" : "Case Study: Hyderabad"}
        </button>
        <button className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-sm transition-colors">
          <Download className="w-4 h-4" />
          Export Report
        </button>
      </div>
    </div>
  );
}
