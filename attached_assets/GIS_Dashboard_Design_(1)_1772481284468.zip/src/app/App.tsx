import { useState } from "react";
import { TopBar } from "./components/TopBar";
import { LeftSidebar } from "./components/LeftSidebar";
import { MapCanvas } from "./components/MapCanvas";
import { RightPanel } from "./components/RightPanel";
import { Sun, Mountain, Wind, Trees, Droplets, Map } from "lucide-react";

interface Layer {
  id: string;
  name: string;
  icon: React.ReactNode;
  enabled: boolean;
  color: string;
}

interface LocationData {
  lat: number;
  lng: number;
  elevation: number;
  zoning: string;
  sunExposure: number;
  soilSuitability: number;
  floodRisk: string;
  windExposure: number;
}

export default function App() {
  const [currentProject] = useState("Downtown Development Analysis");
  const [showCaseStudy, setShowCaseStudy] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationData, setLocationData] = useState<LocationData | null>(null);

  // Hyderabad coordinates for case study
  const defaultCenter: [number, number] = showCaseStudy ? [17.385, 78.4867] : [40.7128, -74.006];
  const defaultZoom = 12;

  const [layers, setLayers] = useState<Layer[]>([
    {
      id: "sun",
      name: "Sun Path",
      icon: <Sun className="w-4 h-4" />,
      enabled: true,
      color: "bg-yellow-600",
    },
    {
      id: "soil",
      name: "Soil Type",
      icon: <Mountain className="w-4 h-4" />,
      enabled: true,
      color: "bg-green-600",
    },
    {
      id: "elevation",
      name: "Elevation",
      icon: <Mountain className="w-4 h-4" />,
      enabled: false,
      color: "bg-blue-600",
    },
    {
      id: "wind",
      name: "Wind",
      icon: <Wind className="w-4 h-4" />,
      enabled: true,
      color: "bg-cyan-600",
    },
    {
      id: "landuse",
      name: "Land Use",
      icon: <Trees className="w-4 h-4" />,
      enabled: false,
      color: "bg-emerald-600",
    },
    {
      id: "flood",
      name: "Flood Risk",
      icon: <Droplets className="w-4 h-4" />,
      enabled: true,
      color: "bg-indigo-600",
    },
  ]);

  const handleToggleLayer = (layerId: string) => {
    setLayers((prevLayers) =>
      prevLayers.map((layer) =>
        layer.id === layerId ? { ...layer, enabled: !layer.enabled } : layer
      )
    );
  };

  const handleMapClick = (lat: number, lng: number) => {
    setSelectedLocation({ lat, lng });

    // Generate mock data based on location
    const mockData: LocationData = {
      lat,
      lng,
      elevation: Math.floor(240 + Math.random() * 50),
      zoning: ["Mixed-Use", "Residential", "Commercial", "Industrial"][
        Math.floor(Math.random() * 4)
      ],
      sunExposure: Math.floor(70 + Math.random() * 25),
      soilSuitability: Math.floor(60 + Math.random() * 30),
      floodRisk: Math.random() > 0.3 ? "Low" : "Moderate",
      windExposure: Math.floor(50 + Math.random() * 40),
    };

    setLocationData(mockData);
  };

  const handleToggleCaseStudy = () => {
    setShowCaseStudy(!showCaseStudy);
    setSelectedLocation(null);
    setLocationData(null);
  };

  return (
    <div className="h-screen flex flex-col bg-[#0a0b0e] dark">
      <TopBar
        currentProject={currentProject}
        showCaseStudy={showCaseStudy}
        onToggleCaseStudy={handleToggleCaseStudy}
      />
      <div className="flex-1 flex overflow-hidden">
        <LeftSidebar
          layers={layers}
          onToggleLayer={handleToggleLayer}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        <div className="flex-1">
          <MapCanvas
            selectedLocation={selectedLocation}
            onMapClick={handleMapClick}
            center={defaultCenter}
            zoom={defaultZoom}
          />
        </div>
        <RightPanel locationData={locationData} />
      </div>
    </div>
  );
}
