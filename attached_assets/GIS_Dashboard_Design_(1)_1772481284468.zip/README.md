
  # GIS Dashboard Design

  This is a code bundle for GIS Dashboard Design. The original project is available at https://www.figma.com/design/YPMi4B2FxXO7Zzs7lmH8KJ/GIS-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  